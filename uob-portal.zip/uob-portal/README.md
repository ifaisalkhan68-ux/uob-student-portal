# UOB Student Services Portal

A React + Vite + Tailwind PWA for University of Buner: a notice board plus a
query/complaint system that routes student issues to the right department
over WhatsApp, with a tracking ID so students can check status later.

## What it does

- **Notice Board** — students see official announcements (public, no login)
- **Submit Query** — student fills a form, gets a reference number
  (e.g. `UOB-QRY-4821`), and is handed a pre-filled WhatsApp message to send
  to the right department
- **Track Query** — student enters their reference number to see status
  (Pending / In Progress / Resolved)
- **Staff Login** — admin signs in to post/delete notices and update query
  status (`/admin/login`)

## 1. Firebase setup (one-time)

1. Go to https://console.firebase.google.com → Create project
2. Add a Web App inside the project → copy the config object
3. Paste it into `src/lib/firebase.js` (replace the placeholder values)
4. In Firebase Console:
   - **Authentication** → Sign-in method → enable **Email/Password**
   - **Authentication** → Users → Add a user (this is your admin login —
     e.g. your email + a password) — this is how staff sign in
   - **Firestore Database** → Create database (production mode)
   - **Firestore Database** → Rules → paste in the contents of
     `firestore.rules` from this project → Publish

## 2. Set your department WhatsApp numbers

Open `src/lib/config.js` and replace the placeholder numbers with the real
WhatsApp numbers for each department (format: country code + number, no `+`,
no spaces — e.g. `923001234567`).

## 3. Install & run locally (optional, only if you have Node/npm)

```
npm install
npm run dev
```

## 4. Deploy (same flow as Arabian Bites)

1. Push this folder to a new GitHub repo
2. Import the repo into Vercel
3. Vercel auto-detects Vite, builds, and deploys
4. Done — you get a live URL to demo to admin staff

## Project structure

```
src/
  components/    Navbar, Footer, NoticeCard
  context/       AuthContext (admin login state)
  lib/           firebase.js (config), config.js (departments), utils.js
  pages/         Notices, SubmitQuery, TrackQuery, AdminLogin, AdminDashboard
```

## Notes for the pitch to admin staff

- Every query gets a stamped reference number, like an official document —
  this is the thing to show off in the demo.
- No login needed for students — lowers the barrier to actually using it.
- Admin only needs WhatsApp + a browser tab for the dashboard — no new
  software to learn.
